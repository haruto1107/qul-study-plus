import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { LessonStatusBadge } from "@/components/LessonStatusBadge";

export const dynamic = "force-dynamic";

export default async function ClassesPage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: memberships } = await supabase
    .from("class_members")
    .select("classes(id, name, subject, profiles:teacher_id(display_name))")
    .eq("student_id", user.id);

  const classes = (memberships ?? []).map((m: any) => m.classes).filter(Boolean);

  // 各授業の直近のlessonと未提出課題数をまとめて取得
  const classIds = classes.map((c: any) => c.id);
  const { data: nextLessons } = classIds.length
    ? await supabase
        .from("lessons")
        .select("*")
        .in("class_id", classIds)
        .in("status", ["scheduled", "live"])
        .order("scheduled_start", { ascending: true })
    : { data: [] as any[] };

  return (
    <main className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-xl font-semibold mb-6">授業一覧</h1>
      <div className="space-y-3">
        {classes.length === 0 && (
          <Card className="text-sm text-slate-400">参加している授業はまだありません</Card>
        )}
        {classes.map((c: any) => {
          const next = (nextLessons ?? []).find((l: any) => l.class_id === c.id);
          return (
            <Card key={c.id}>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="text-xs text-slate-400">{c.subject}</p>
                  <p className="font-semibold">{c.name}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{c.profiles?.display_name}先生</p>
                </div>
                {next && <LessonStatusBadge status={next.status} />}
              </div>
              {next && (
                <Link href={`/lessons/${next.id}`} className="text-sm text-qul-600">
                  次回授業を見る →
                </Link>
              )}
            </Card>
          );
        })}
      </div>
    </main>
  );
}
