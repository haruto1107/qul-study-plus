import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { LessonStatusBadge } from "@/components/LessonStatusBadge";

export const dynamic = "force-dynamic";

export default async function LessonDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: lesson } = await supabase
    .from("lessons")
    .select("*, classes(name, subject, teacher_id, profiles:teacher_id(display_name))")
    .eq("id", params.id)
    .single();

  if (!lesson) notFound();

  const { data: materials } = await supabase
    .from("lesson_materials")
    .select("*, materials(title, description, file_type)")
    .eq("lesson_id", lesson.id)
    .order("delivered_at", { ascending: false });

  const { data: assignments } = await supabase
    .from("assignments")
    .select("*")
    .eq("lesson_id", lesson.id);

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-400">{lesson.classes?.subject}</p>
          <h1 className="text-xl font-semibold">{lesson.title}</h1>
          <p className="text-xs text-slate-400 mt-1">{lesson.classes?.profiles?.display_name}先生</p>
        </div>
        <LessonStatusBadge status={lesson.status} />
      </div>

      {lesson.status === "live" && (
        <Link href={`/lessons/${lesson.id}/room`} className="qul-btn-primary w-full block text-center">
          🔵 授業に入室する
        </Link>
      )}

      <section>
        <h2 className="text-sm font-semibold text-slate-500 mb-3">資料</h2>
        <div className="space-y-2">
          {(materials ?? []).length === 0 && (
            <Card className="text-sm text-slate-400">配信された資料はまだありません</Card>
          )}
          {(materials ?? []).map((lm: any) => (
            <Card key={lm.id} className="py-3">
              <p className="text-sm font-medium">{lm.materials?.title}</p>
              {lm.materials?.description && (
                <p className="text-xs text-slate-400 mt-1">{lm.materials.description}</p>
              )}
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-sm font-semibold text-slate-500 mb-3">課題</h2>
        <div className="space-y-2">
          {(assignments ?? []).length === 0 && (
            <Card className="text-sm text-slate-400">配信された課題はまだありません</Card>
          )}
          {(assignments ?? []).map((a) => (
            <Card key={a.id} className="py-3">
              <p className="text-sm font-medium">{a.title}</p>
              {a.due_at && (
                <p className="text-xs text-slate-400 mt-1">
                  締切: {new Date(a.due_at).toLocaleString("ja-JP")}
                </p>
              )}
            </Card>
          ))}
        </div>
      </section>
    </main>
  );
}
