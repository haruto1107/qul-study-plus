import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { joinLesson } from "@/app/lessons/[id]/actions";
import { RoomClient } from "./RoomClient";

export const dynamic = "force-dynamic";

export default async function LessonRoomPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: lesson } = await supabase
    .from("lessons")
    .select("*, classes(name, subject, teacher_id, profiles:teacher_id(display_name))")
    .eq("id", params.id)
    .single();

  if (!lesson) notFound();
  if (lesson.status !== "live") redirect(`/lessons/${lesson.id}`);

  // 入室記録 (lesson_members) をここで作成する
  await joinLesson(lesson.id);

  const { data: materials } = await supabase
    .from("lesson_materials")
    .select("*, materials(title, description, file_type)")
    .eq("lesson_id", lesson.id)
    .order("delivered_at", { ascending: false });

  return (
    <RoomClient
      lesson={lesson as any}
      initialMaterials={(materials ?? []) as any}
      studentId={user.id}
    />
  );
}
