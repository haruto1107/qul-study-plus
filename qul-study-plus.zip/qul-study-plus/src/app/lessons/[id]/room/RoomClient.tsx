"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useLessonRealtime } from "@/hooks/useLessonRealtime";
import { MaterialFeed } from "@/components/MaterialFeed";
import { AssignmentPanel } from "@/components/AssignmentPanel";
import type { Lesson, LessonMaterial } from "@/lib/supabase/types";

type Tab = "materials" | "assignments" | "board" | "shared_board" | "comments";

const TABS: { key: Tab; label: string }[] = [
  { key: "materials", label: "資料" },
  { key: "assignments", label: "課題" },
  { key: "board", label: "マイボード" },
  { key: "shared_board", label: "みんなのボード" },
  { key: "comments", label: "コメント" }
];

export function RoomClient({
  lesson,
  initialMaterials,
  studentId
}: {
  lesson: Lesson & { classes?: any };
  initialMaterials: LessonMaterial[];
  studentId: string;
}) {
  const router = useRouter();
  const { lesson: liveLesson, materials } = useLessonRealtime(lesson.id, lesson, initialMaterials);
  const [tab, setTab] = useState<Tab>("materials");

  // 先生が授業を終了した瞬間、生徒側も授業詳細ページへ戻す
  if (liveLesson.status === "ended") {
    router.replace(`/lessons/${lesson.id}`);
  }

  return (
    <main className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <header className="sticky top-0 z-10 bg-white/90 dark:bg-slate-900/90 backdrop-blur border-b border-slate-100 dark:border-slate-800 px-4 py-3">
        <p className="text-xs text-slate-400">{lesson.classes?.subject}</p>
        <div className="flex items-center justify-between">
          <h1 className="font-semibold">{lesson.title}</h1>
          <span className="qul-badge bg-red-50 text-red-600">
            <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" /> 授業中
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-0.5">{lesson.classes?.profiles?.display_name}先生</p>
      </header>

      <nav className="flex gap-1 overflow-x-auto px-4 py-3 text-sm">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={
              "shrink-0 rounded-full px-4 py-1.5 " +
              (tab === t.key
                ? "bg-qul-500 text-white"
                : "bg-white dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700")
            }
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="px-4 pb-10">
        {tab === "materials" && <MaterialFeed materials={materials} />}
        {tab === "assignments" && <AssignmentPanel lessonId={lesson.id} studentId={studentId} />}
        {(tab === "board" || tab === "shared_board" || tab === "comments") && (
          <div className="qul-card text-sm text-slate-400">
            この機能はPhase 2で実装予定です。
          </div>
        )}
      </div>
    </main>
  );
}
