"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function joinLesson(lessonId: string) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) throw new Error("ログインが必要です");

  const { error } = await supabase
    .from("lesson_members")
    .upsert(
      { lesson_id: lessonId, student_id: user.id, joined_at: new Date().toISOString(), last_seen_at: new Date().toISOString() },
      { onConflict: "lesson_id,student_id" }
    );

  if (error) throw new Error(error.message);
  revalidatePath(`/lessons/${lessonId}/room`);
}

export async function submitAssignment(
  assignmentId: string,
  answerText: string
) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) throw new Error("ログインが必要です");

  const { error } = await supabase.from("assignment_submissions").upsert(
    {
      assignment_id: assignmentId,
      student_id: user.id,
      answer_text: answerText,
      status: "submitted",
      submitted_at: new Date().toISOString()
    },
    { onConflict: "assignment_id,student_id" }
  );

  if (error) throw new Error(error.message);
}
