"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function startLesson(lessonId: string) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) throw new Error("ログインが必要です");

  const { error } = await supabase
    .from("lessons")
    .update({ status: "live", started_at: new Date().toISOString() })
    .eq("id", lessonId);

  if (error) throw new Error(error.message);

  await supabase.from("lesson_sessions").insert({ lesson_id: lessonId });

  redirect(`/teacher/lessons/${lessonId}/live`);
}
