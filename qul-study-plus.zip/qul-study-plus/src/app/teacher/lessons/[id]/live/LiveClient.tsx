"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/ui/Card";
import {
  endLesson,
  deliverMaterial,
  createAssignment,
  returnSubmission,
  requestResubmit
} from "./actions";

type Tab = "participants" | "materials" | "assignments" | "submissions";

const TABS: { key: Tab; label: string }[] = [
  { key: "participants", label: "参加者" },
  { key: "materials", label: "資料配信" },
  { key: "assignments", label: "課題" },
  { key: "submissions", label: "提出BOX" }
];

export function LiveClient({
  lesson,
  initialMembers,
  initialMaterials,
  initialAssignments,
  initialSubmissions
}: {
  lesson: any;
  initialMembers: any[];
  initialMaterials: any[];
  initialAssignments: any[];
  initialSubmissions: any[];
}) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("participants");
  const [members, setMembers] = useState(initialMembers);
  const [materials, setMaterials] = useState(initialMaterials);
  const [assignments, setAssignments] = useState(initialAssignments);
  const [submissions, setSubmissions] = useState(initialSubmissions);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    const supabase = createClient();
    const channel = supabase
      .channel(`teacher-live-${lesson.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "lesson_members", filter: `lesson_id=eq.${lesson.id}` },
        async () => {
          const { data } = await supabase
            .from("lesson_members")
            .select("*, profiles:student_id(display_name)")
            .eq("lesson_id", lesson.id);
          setMembers(data ?? []);
        }
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "assignment_submissions" },
        async (payload) => {
          const assignmentIds = assignments.map((a) => a.id);
          const changedId = (payload.new as any)?.assignment_id ?? (payload.old as any)?.assignment_id;
          if (!assignmentIds.includes(changedId)) return;
          const { data } = await supabase
            .from("assignment_submissions")
            .select("*, profiles:student_id(display_name), assignments(title)")
            .in("assignment_id", assignmentIds);
          setSubmissions(data ?? []);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lesson.id, assignments.length]);

  function handleEndLesson() {
    startTransition(async () => {
      await endLesson(lesson.id);
      router.push("/teacher");
    });
  }

  return (
    <main className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <header className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 px-4 py-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400">{lesson.classes?.subject}</p>
            <h1 className="font-semibold text-lg">{lesson.title}</h1>
            <p className="text-xs text-slate-400 mt-0.5">参加者 {members.length}人</p>
          </div>
          <button
            onClick={handleEndLesson}
            disabled={isPending}
            className="rounded-xl2 border border-red-200 text-red-500 px-4 py-2 text-sm font-medium hover:bg-red-50"
          >
            授業終了
          </button>
        </div>
      </header>

      <nav className="flex gap-1 overflow-x-auto px-4 py-3 text-sm">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={
              "shrink-0 rounded-full px-4 py-1.5 " +
              (tab === t.key
                ? "bg-qul-500 text-white"
                : "bg-white dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700")
            }
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="px-4 pb-10 space-y-3">
        {tab === "participants" && (
          <>
            {members.length === 0 && <Card className="text-sm text-slate-400">まだ入室者はいません</Card>}
            {members.map((m) => (
              <Card key={m.id} className="flex items-center justify-between py-3">
                <span className="text-sm font-medium">{m.profiles?.display_name}</span>
                <span className="text-xs text-slate-400">
                  {m.joined_at ? `入室 ${new Date(m.joined_at).toLocaleTimeString("ja-JP")}` : "未入室"}
                </span>
              </Card>
            ))}
          </>
        )}

        {tab === "materials" && (
          <>
            <Card>
              <form
                action={async (formData) => {
                  await deliverMaterial(lesson.id, formData);
                }}
                className="space-y-3"
              >
                <input
                  name="title"
                  placeholder="資料タイトル"
                  required
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
                />
                <textarea
                  name="description"
                  placeholder="説明(任意)"
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
                />
                <input type="file" name="file" required className="text-sm" />
                <button type="submit" className="qul-btn-primary text-sm py-2 px-4">
                  資料を配信する
                </button>
              </form>
            </Card>
            {materials.map((lm) => (
              <Card key={lm.id} className="py-3">
                <p className="text-sm font-medium">{lm.materials?.title}</p>
                <p className="text-xs text-slate-400">
                  配信: {new Date(lm.delivered_at).toLocaleTimeString("ja-JP")}
                </p>
              </Card>
            ))}
          </>
        )}

        {tab === "assignments" && (
          <>
            <Card>
              <form
                action={async (formData) => {
                  await createAssignment(lesson.id, lesson.class_id, formData);
                }}
                className="space-y-3"
              >
                <input
                  name="title"
                  placeholder="課題タイトル"
                  required
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
                />
                <textarea
                  name="description"
                  placeholder="説明(任意)"
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
                />
                <input
                  type="datetime-local"
                  name="due_at"
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
                />
                <button type="submit" className="qul-btn-primary text-sm py-2 px-4">
                  課題を配信する
                </button>
              </form>
            </Card>
            {assignments.map((a) => (
              <Card key={a.id} className="py-3">
                <p className="text-sm font-medium">{a.title}</p>
              </Card>
            ))}
          </>
        )}

        {tab === "submissions" && (
          <>
            {submissions.length === 0 && <Card className="text-sm text-slate-400">提出物はまだありません</Card>}
            {submissions.map((s) => (
              <SubmissionRow key={s.id} submission={s} />
            ))}
          </>
        )}
      </div>
    </main>
  );
}

function SubmissionRow({ submission }: { submission: any }) {
  const [comment, setComment] = useState("");
  const [isPending, startTransition] = useTransition();

  const statusLabel: Record<string, string> = {
    not_submitted: "未提出",
    submitted: "提出済み",
    returned: "返却済み",
    resubmit_requested: "再提出待ち"
  };

  return (
    <Card>
      <div className="flex items-center justify-between mb-2">
        <div>
          <p className="text-sm font-medium">{submission.profiles?.display_name}</p>
          <p className="text-xs text-slate-400">{submission.assignments?.title}</p>
        </div>
        <span className="qul-badge bg-qul-50 text-qul-700">{statusLabel[submission.status]}</span>
      </div>
      {submission.answer_text && (
        <p className="text-sm bg-slate-50 dark:bg-slate-800 rounded-xl2 p-3 mb-2 whitespace-pre-wrap">
          {submission.answer_text}
        </p>
      )}
      <div className="flex gap-2">
        <input
          placeholder="コメント"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="flex-1 rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm"
        />
        <button
          disabled={isPending}
          onClick={() => startTransition(() => returnSubmission(submission.id, comment))}
          className="qul-btn-secondary text-sm py-2 px-3"
        >
          返却
        </button>
        <button
          disabled={isPending}
          onClick={() => startTransition(() => requestResubmit(submission.id, comment))}
          className="qul-btn-secondary text-sm py-2 px-3"
        >
          再提出依頼
        </button>
      </div>
    </Card>
  );
}
