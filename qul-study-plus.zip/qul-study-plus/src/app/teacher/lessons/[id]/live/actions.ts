"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function endLesson(lessonId: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("lessons")
    .update({ status: "ended", ended_at: new Date().toISOString() })
    .eq("id", lessonId);
  if (error) throw new Error(error.message);

  await supabase
    .from("lesson_sessions")
    .update({ ended_at: new Date().toISOString() })
    .eq("lesson_id", lessonId)
    .is("ended_at", null);

  revalidatePath(`/teacher/lessons/${lessonId}/live`);
}

export async function deliverMaterial(lessonId: string, formData: FormData) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) throw new Error("ログインが必要です");

  const title = String(formData.get("title") ?? "");
  const description = String(formData.get("description") ?? "");
  const file = formData.get("file") as File | null;

  if (!title || !file) throw new Error("タイトルとファイルは必須です");

  const path = `${lessonId}/${Date.now()}_${file.name}`;
  const { error: uploadError } = await supabase.storage
    .from("lesson-materials")
    .upload(path, file, { contentType: file.type });
  if (uploadError) throw new Error(uploadError.message);

  const { data: material, error: materialError } = await supabase
    .from("materials")
    .insert({
      owner_id: user.id,
      title,
      description,
      file_path: path,
      file_type: file.type
    })
    .select()
    .single();
  if (materialError) throw new Error(materialError.message);

  const { error: deliverError } = await supabase.from("lesson_materials").insert({
    lesson_id: lessonId,
    material_id: material.id,
    delivered_by: user.id
  });
  if (deliverError) throw new Error(deliverError.message);

  revalidatePath(`/teacher/lessons/${lessonId}/live`);
}

export async function createAssignment(lessonId: string, classId: string, formData: FormData) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) throw new Error("ログインが必要です");

  const title = String(formData.get("title") ?? "");
  const description = String(formData.get("description") ?? "");
  const dueAt = formData.get("due_at") ? String(formData.get("due_at")) : null;

  if (!title) throw new Error("タイトルは必須です");

  const { error } = await supabase.from("assignments").insert({
    lesson_id: lessonId,
    class_id: classId,
    teacher_id: user.id,
    title,
    description,
    due_at: dueAt
  });
  if (error) throw new Error(error.message);

  revalidatePath(`/teacher/lessons/${lessonId}/live`);
}

export async function returnSubmission(submissionId: string, comment: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("assignment_submissions")
    .update({ status: "returned", teacher_comment: comment, returned_at: new Date().toISOString() })
    .eq("id", submissionId);
  if (error) throw new Error(error.message);
}

export async function requestResubmit(submissionId: string, comment: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("assignment_submissions")
    .update({ status: "resubmit_requested", teacher_comment: comment })
    .eq("id", submissionId);
  if (error) throw new Error(error.message);
}
