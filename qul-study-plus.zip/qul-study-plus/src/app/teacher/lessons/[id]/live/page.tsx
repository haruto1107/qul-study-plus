import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { LiveClient } from "./LiveClient";

export const dynamic = "force-dynamic";

export default async function TeacherLiveLessonPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: lesson } = await supabase
    .from("lessons")
    .select("*, classes(id, name, subject, teacher_id)")
    .eq("id", params.id)
    .single();

  if (!lesson) notFound();
  if (lesson.classes?.teacher_id !== user.id) redirect("/teacher");

  const [{ data: members }, { data: materials }, { data: assignments }, { data: submissions }] =
    await Promise.all([
      supabase.from("lesson_members").select("*, profiles:student_id(display_name)").eq("lesson_id", lesson.id),
      supabase
        .from("lesson_materials")
        .select("*, materials(title, description)")
        .eq("lesson_id", lesson.id)
        .order("delivered_at", { ascending: false }),
      supabase.from("assignments").select("*").eq("lesson_id", lesson.id),
      supabase
        .from("assignment_submissions")
        .select("*, profiles:student_id(display_name), assignments(title)")
        .in(
          "assignment_id",
          (
            await supabase.from("assignments").select("id").eq("lesson_id", lesson.id)
          ).data?.map((a) => a.id) ?? []
        )
    ]);

  return (
    <LiveClient
      lesson={lesson as any}
      initialMembers={(members ?? []) as any}
      initialMaterials={(materials ?? []) as any}
      initialAssignments={(assignments ?? []) as any}
      initialSubmissions={(submissions ?? []) as any}
    />
  );
}
