import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { startLesson } from "./actions";

export const dynamic = "force-dynamic";

export default async function TeacherDashboardPage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  const { data: myClasses } = await supabase.from("classes").select("id").eq("teacher_id", user.id);
  const classIds = (myClasses ?? []).map((c) => c.id);

  const { data: lessons } = classIds.length
    ? await supabase
        .from("lessons")
        .select("*, classes(name, subject)")
        .in("class_id", classIds)
        .or(`status.eq.live,and(scheduled_start.gte.${startOfDay.toISOString()},scheduled_start.lte.${endOfDay.toISOString()})`)
        .order("scheduled_start", { ascending: true })
    : { data: [] as any[] };

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 space-y-6">
      <h1 className="text-xl font-semibold">{profile?.display_name}先生、こんにちは</h1>

      <section>
        <h2 className="text-sm font-semibold text-slate-500 mb-3">今日の授業</h2>
        <div className="space-y-3">
          {(lessons ?? []).length === 0 && (
            <Card className="text-sm text-slate-400">今日の授業予定はありません</Card>
          )}
          {(lessons ?? []).map((lesson: any) => (
            <Card key={lesson.id}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">{lesson.classes?.subject}</p>
                  <p className="font-medium">{lesson.title}</p>
                  <p className="text-xs text-slate-400 mt-1">
                    {new Date(lesson.scheduled_start).toLocaleTimeString("ja-JP", {
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                    〜
                  </p>
                </div>

                {lesson.status === "live" ? (
                  <Link href={`/teacher/lessons/${lesson.id}/live`} className="qul-btn-primary text-sm py-2 px-4">
                    授業ダッシュボード
                  </Link>
                ) : (
                  <form action={async () => {
                    "use server";
                    await startLesson(lesson.id);
                  }}>
                    <button type="submit" className="qul-btn-primary text-sm py-2 px-4">
                      授業開始
                    </button>
                  </form>
                )}
              </div>
            </Card>
          ))}
        </div>
      </section>
    </main>
  );
}
