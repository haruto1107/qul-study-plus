import Link from "next/link";

export default function TeacherLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <header className="border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 flex items-center justify-between">
        <Link href="/teacher" className="font-semibold text-qul-700 dark:text-qul-200">
          QUL Study Plus <span className="text-xs text-slate-400 font-normal">先生</span>
        </Link>
        <nav className="flex gap-4 text-sm text-slate-500">
          <Link href="/teacher">ダッシュボード</Link>
          <Link href="/teacher/reservations">予約</Link>
        </nav>
      </header>
      {children}
    </div>
  );
}
