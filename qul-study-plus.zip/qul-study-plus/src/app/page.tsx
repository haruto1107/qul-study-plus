import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { LessonStatusBadge } from "@/components/LessonStatusBadge";

export const dynamic = "force-dynamic";

export default async function StudentHomePage() {
  const supabase = createClient();

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (profile?.role === "teacher" || profile?.role === "admin") {
    redirect("/teacher");
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  const { data: memberships } = await supabase
    .from("class_members")
    .select("class_id")
    .eq("student_id", user.id);

  const classIds = (memberships ?? []).map((m) => m.class_id);

  const { data: lessons } = classIds.length
    ? await supabase
        .from("lessons")
        .select("*, classes(name, subject, teacher_id, profiles:teacher_id(display_name))")
        .in("class_id", classIds)
        .or(`status.eq.live,and(scheduled_start.gte.${startOfDay.toISOString()},scheduled_start.lte.${endOfDay.toISOString()})`)
        .order("scheduled_start", { ascending: true })
    : { data: [] as any[] };

  const liveLesson = (lessons ?? []).find((l: any) => l.status === "live");

  const { data: homeworkList } = await supabase
    .from("homework")
    .select("*")
    .eq("student_id", user.id)
    .neq("status", "done")
    .order("due_at", { ascending: true })
    .limit(5);

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">おかえりなさい</p>
          <h1 className="text-xl font-semibold">{profile?.display_name ?? "生徒"}さん</h1>
        </div>
        <Link href="/mypage" className="text-sm text-qul-600">
          マイページ
        </Link>
      </header>

      {liveLesson && (
        <Link
          href={`/lessons/${liveLesson.id}/room`}
          className="block qul-card border-2 border-qul-400 bg-qul-50 dark:bg-qul-900/30"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-qul-600 mb-1">
                {liveLesson.classes?.subject} ・ {liveLesson.classes?.profiles?.display_name}先生
              </p>
              <p className="text-lg font-semibold">{liveLesson.title}</p>
            </div>
            <span className="qul-btn-primary shrink-0">🔵 授業に入室する</span>
          </div>
        </Link>
      )}

      <section>
        <h2 className="text-sm font-semibold text-slate-500 mb-3">今日の授業</h2>
        <div className="space-y-3">
          {(lessons ?? []).length === 0 && (
            <Card className="text-sm text-slate-400">今日の授業はありません</Card>
          )}
          {(lessons ?? []).map((lesson: any) => (
            <Link key={lesson.id} href={`/lessons/${lesson.id}`}>
              <Card className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 mb-0.5">{lesson.classes?.subject}</p>
                  <p className="font-medium">{lesson.title}</p>
                  <p className="text-xs text-slate-400 mt-1">
                    {new Date(lesson.scheduled_start).toLocaleTimeString("ja-JP", {
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                    〜
                  </p>
                </div>
                <LessonStatusBadge status={lesson.status} />
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-sm font-semibold text-slate-500 mb-3">今日の宿題</h2>
        <div className="space-y-2">
          {(homeworkList ?? []).length === 0 && (
            <Card className="text-sm text-slate-400">未完了の宿題はありません</Card>
          )}
          {(homeworkList ?? []).map((hw) => (
            <Card key={hw.id} className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium">{hw.title}</p>
                {hw.due_at && (
                  <p className="text-xs text-slate-400">
                    締切: {new Date(hw.due_at).toLocaleString("ja-JP")}
                  </p>
                )}
              </div>
              <span className="qul-badge bg-qul-50 text-qul-700">{hw.status}</span>
            </Card>
          ))}
        </div>
      </section>

      <nav className="grid grid-cols-3 gap-3 text-center text-sm pt-4">
        <Link href="/classes" className="qul-card py-4">
          授業一覧
        </Link>
        <Link href="/study/timer" className="qul-card py-4">
          勉強時間
        </Link>
        <Link href="/reservations" className="qul-card py-4">
          予約
        </Link>
      </nav>
    </main>
  );
}
