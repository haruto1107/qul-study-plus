import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { reserveSlot } from "./actions";

export const dynamic = "force-dynamic";

export default async function ReservationsPage() {
  const supabase = createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: slots } = await supabase
    .from("reservation_slots")
    .select("*")
    .gte("starts_at", new Date().toISOString())
    .order("starts_at", { ascending: true });

  const { data: myReservations } = await supabase
    .from("reservations")
    .select("slot_id")
    .eq("student_id", user.id)
    .eq("status", "confirmed");

  const reservedSlotIds = new Set((myReservations ?? []).map((r) => r.slot_id));

  const counts = new Map<string, number>();
  if (slots?.length) {
    const { data: allReservations } = await supabase
      .from("reservations")
      .select("slot_id")
      .in("slot_id", slots.map((s) => s.id))
      .eq("status", "confirmed");
    (allReservations ?? []).forEach((r) => counts.set(r.slot_id, (counts.get(r.slot_id) ?? 0) + 1));
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-xl font-semibold mb-6">予約</h1>
      <div className="space-y-3">
        {(slots ?? []).length === 0 && <Card className="text-sm text-slate-400">予約可能な枠はありません</Card>}
        {(slots ?? []).map((slot) => {
          const taken = counts.get(slot.id) ?? 0;
          const isFull = taken >= slot.capacity;
          const isReserved = reservedSlotIds.has(slot.id);
          return (
            <Card key={slot.id} className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">{slot.category}</p>
                <p className="font-medium">{slot.title}</p>
                <p className="text-xs text-slate-400 mt-1">
                  {new Date(slot.starts_at).toLocaleString("ja-JP")} 〜 空き {slot.capacity - taken}/{slot.capacity}
                </p>
              </div>
              {isReserved ? (
                <span className="qul-badge bg-qul-50 text-qul-700">予約済み</span>
              ) : (
                <form
                  action={async () => {
                    "use server";
                    await reserveSlot(slot.id);
                  }}
                >
                  <button
                    type="submit"
                    disabled={isFull}
                    className="qul-btn-primary text-sm py-2 px-4"
                  >
                    {isFull ? "満員" : "予約する"}
                  </button>
                </form>
              )}
            </Card>
          );
        })}
      </div>
    </main>
  );
}
