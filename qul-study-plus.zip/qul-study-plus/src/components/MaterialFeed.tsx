import { Card } from "@/components/ui/Card";
import type { LessonMaterial } from "@/lib/supabase/types";

export function MaterialFeed({ materials }: { materials: LessonMaterial[] }) {
  if (materials.length === 0) {
    return <Card className="text-sm text-slate-400">まだ資料は配信されていません</Card>;
  }

  return (
    <div className="space-y-2">
      {materials.map((lm) => (
        <Card key={lm.id} className="py-3">
          <p className="text-xs text-qul-600 mb-0.5">先生からの資料</p>
          <p className="text-sm font-medium">{lm.material?.title}</p>
          {lm.material?.description && (
            <p className="text-xs text-slate-400 mt-1">{lm.material.description}</p>
          )}
        </Card>
      ))}
    </div>
  );
}
