"use client";

import { useEffect, useState, useTransition } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/ui/Card";
import { submitAssignment } from "@/app/lessons/[id]/actions";
import type { Assignment, AssignmentSubmission } from "@/lib/supabase/types";

export function AssignmentPanel({ lessonId, studentId }: { lessonId: string; studentId: string }) {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<Record<string, AssignmentSubmission>>({});
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    const supabase = createClient();

    async function load() {
      const { data: assignmentData } = await supabase
        .from("assignments")
        .select("*")
        .eq("lesson_id", lessonId)
        .order("created_at", { ascending: true });
      setAssignments(assignmentData ?? []);

      const { data: submissionData } = await supabase
        .from("assignment_submissions")
        .select("*")
        .eq("student_id", studentId);

      const map: Record<string, AssignmentSubmission> = {};
      (submissionData ?? []).forEach((s) => (map[s.assignment_id] = s as AssignmentSubmission));
      setSubmissions(map);
    }
    load();

    const channel = supabase
      .channel(`assignments-${lessonId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "assignments", filter: `lesson_id=eq.${lessonId}` },
        (payload) => setAssignments((prev) => [...prev, payload.new as Assignment])
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [lessonId, studentId]);

  function handleSubmit(assignmentId: string) {
    const text = drafts[assignmentId] ?? "";
    startTransition(async () => {
      await submitAssignment(assignmentId, text);
      setSubmissions((prev) => ({
        ...prev,
        [assignmentId]: {
          ...(prev[assignmentId] as AssignmentSubmission),
          assignment_id: assignmentId,
          student_id: studentId,
          status: "submitted",
          answer_text: text
        } as AssignmentSubmission
      }));
    });
  }

  if (assignments.length === 0) {
    return <Card className="text-sm text-slate-400">配信された課題はまだありません</Card>;
  }

  return (
    <div className="space-y-3">
      {assignments.map((a) => {
        const submission = submissions[a.id];
        const isSubmitted = submission?.status === "submitted" || submission?.status === "returned";
        return (
          <Card key={a.id}>
            <p className="text-sm font-medium mb-1">{a.title}</p>
            {a.description && <p className="text-xs text-slate-400 mb-3">{a.description}</p>}

            {submission?.status === "returned" ? (
              <div className="text-sm text-qul-700 bg-qul-50 rounded-xl2 p-3">
                <p className="font-medium mb-1">返却済み</p>
                {submission.teacher_comment && <p className="text-xs">{submission.teacher_comment}</p>}
              </div>
            ) : (
              <>
                <textarea
                  disabled={isSubmitted}
                  defaultValue={submission?.answer_text ?? ""}
                  onChange={(e) => setDrafts((prev) => ({ ...prev, [a.id]: e.target.value }))}
                  placeholder="回答を入力"
                  className="w-full rounded-xl2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-qul-400 min-h-[80px]"
                />
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-slate-400">
                    {isSubmitted ? "提出済み" : "未提出"}
                  </span>
                  <button
                    disabled={isPending || isSubmitted}
                    onClick={() => handleSubmit(a.id)}
                    className="qul-btn-primary py-2 px-4 text-sm"
                  >
                    提出する
                  </button>
                </div>
              </>
            )}
          </Card>
        );
      })}
    </div>
  );
}
