import type { LessonStatus } from "@/lib/supabase/types";
import clsx from "clsx";

const LABEL: Record<LessonStatus, string> = {
  scheduled: "予定",
  live: "授業中",
  ended: "終了"
};

const STYLE: Record<LessonStatus, string> = {
  scheduled: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  live: "bg-red-50 text-red-600 dark:bg-red-950 dark:text-red-300",
  ended: "bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500"
};

export function LessonStatusBadge({ status }: { status: LessonStatus }) {
  return (
    <span className={clsx("qul-badge", STYLE[status])}>
      {status === "live" && <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse" />}
      {LABEL[status]}
    </span>
  );
}
