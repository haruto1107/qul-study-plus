-- QUL Study Plus - initial schema (Phase 1 focus)
-- 既存のQUL関連プロジェクトとテーブル名が衝突しないよう、
-- このマイグレーションは新規Supabaseプロジェクトへの適用を前提とする。
-- 既存プロジェクトに適用する場合は、テーブル名の重複がないか必ず事前確認すること。

create extension if not exists "pgcrypto";

-- =========================================================
-- 1. ロール / プロフィール
-- =========================================================

create type user_role as enum ('student', 'teacher', 'admin');
create type lesson_status as enum ('scheduled', 'live', 'ended');
create type submission_status as enum ('not_submitted', 'submitted', 'returned', 'resubmit_requested');
create type board_type as enum ('my', 'shared');
create type reaction_kind as enum ('thumbs_up', 'smile', 'question', 'raise_hand');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null default 'student',
  display_name text not null,
  avatar_url text,
  grade text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- =========================================================
-- 2. 授業 (classes / lessons)
-- =========================================================

create table classes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  subject text not null,
  teacher_id uuid not null references profiles(id) on delete restrict,
  description text,
  created_at timestamptz not null default now()
);

create table class_members (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references classes(id) on delete cascade,
  student_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (class_id, student_id)
);

create table lessons (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references classes(id) on delete cascade,
  title text not null,
  status lesson_status not null default 'scheduled',
  scheduled_start timestamptz not null,
  scheduled_end timestamptz,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create table lesson_members (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  student_id uuid not null references profiles(id) on delete cascade,
  joined_at timestamptz,
  last_seen_at timestamptz,
  unique (lesson_id, student_id)
);

-- 授業が live だった各区間の履歴 (授業記録)
create table lesson_sessions (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  participant_count int not null default 0
);

-- =========================================================
-- 3. 資料配信
-- =========================================================

create table materials (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text,
  file_path text not null, -- Supabase Storage 内のパス (bucket: lesson-materials)
  file_type text,
  created_at timestamptz not null default now()
);

create table lesson_materials (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  material_id uuid not null references materials(id) on delete cascade,
  delivered_at timestamptz not null default now(),
  delivered_by uuid not null references profiles(id)
);

-- =========================================================
-- 4. 課題 / 提出
-- =========================================================

create table assignments (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references lessons(id) on delete set null,
  class_id uuid not null references classes(id) on delete cascade,
  teacher_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text,
  subject text,
  attachment_material_id uuid references materials(id),
  due_at timestamptz,
  submission_format text not null default 'text', -- text / file
  allow_resubmit boolean not null default true,
  created_at timestamptz not null default now()
);

create table assignment_submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references assignments(id) on delete cascade,
  student_id uuid not null references profiles(id) on delete cascade,
  status submission_status not null default 'not_submitted',
  answer_text text,
  answer_file_path text,
  submitted_at timestamptz,
  returned_at timestamptz,
  teacher_comment text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (assignment_id, student_id)
);

-- =========================================================
-- 5. ボード / コメント / リアクション (Phase 2 だが土台として定義)
-- =========================================================

create table boards (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  type board_type not null,
  owner_id uuid references profiles(id) on delete cascade, -- my board のみ設定
  posting_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table board_cards (
  id uuid primary key default gen_random_uuid(),
  board_id uuid not null references boards(id) on delete cascade,
  author_id uuid not null references profiles(id) on delete cascade,
  content text,
  image_path text,
  position_x double precision not null default 0,
  position_y double precision not null default 0,
  is_pinned boolean not null default false,
  is_hidden boolean not null default false,
  created_at timestamptz not null default now()
);

create table comments (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  author_id uuid not null references profiles(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now()
);

create table reactions (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  author_id uuid not null references profiles(id) on delete cascade,
  kind reaction_kind not null,
  created_at timestamptz not null default now()
);

-- =========================================================
-- 6. 勉強時間 / 宿題 / 目標 (Phase 2)
-- =========================================================

create table study_sessions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  subject text,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  duration_seconds int,
  note text
);

create table study_goals (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  period text not null, -- daily / weekly / monthly / long_term
  target_description text not null,
  target_value numeric,
  target_unit text,
  starts_on date,
  ends_on date,
  created_at timestamptz not null default now()
);

create table homework (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  assignment_id uuid references assignments(id) on delete set null, -- 授業配信課題との紐付け
  title text not null,
  subject text,
  due_at timestamptz,
  status text not null default 'not_started', -- not_started / in_progress / done
  memo text,
  created_at timestamptz not null default now()
);

-- =========================================================
-- 7. 予約
-- =========================================================

create table reservation_slots (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references profiles(id) on delete cascade,
  category text not null, -- lesson / meeting / self_study / other
  title text not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  capacity int not null default 1,
  created_at timestamptz not null default now()
);

create table reservations (
  id uuid primary key default gen_random_uuid(),
  slot_id uuid not null references reservation_slots(id) on delete cascade,
  student_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'confirmed', -- confirmed / cancelled
  created_at timestamptz not null default now(),
  unique (slot_id, student_id)
);

-- =========================================================
-- 8. 通知
-- =========================================================

create table notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- =========================================================
-- Helper: 現在ユーザーのロール判定
-- =========================================================

create or replace function is_admin()
returns boolean language sql stable as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function is_teacher_of_class(target_class_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from classes where id = target_class_id and teacher_id = auth.uid()
  );
$$;

create or replace function is_member_of_class(target_class_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from class_members where class_id = target_class_id and student_id = auth.uid()
  );
$$;

-- =========================================================
-- RLS 有効化
-- =========================================================

alter table profiles enable row level security;
alter table classes enable row level security;
alter table class_members enable row level security;
alter table lessons enable row level security;
alter table lesson_members enable row level security;
alter table lesson_sessions enable row level security;
alter table materials enable row level security;
alter table lesson_materials enable row level security;
alter table assignments enable row level security;
alter table assignment_submissions enable row level security;
alter table boards enable row level security;
alter table board_cards enable row level security;
alter table comments enable row level security;
alter table reactions enable row level security;
alter table study_sessions enable row level security;
alter table study_goals enable row level security;
alter table homework enable row level security;
alter table reservation_slots enable row level security;
alter table reservations enable row level security;
alter table notifications enable row level security;

-- ---- profiles ----
create policy "profiles_select_self_or_admin_or_teacher" on profiles
  for select using (
    id = auth.uid() or is_admin() or
    exists (select 1 from classes c where c.teacher_id = auth.uid() and exists (
      select 1 from class_members cm where cm.class_id = c.id and cm.student_id = profiles.id
    ))
  );
create policy "profiles_update_self" on profiles
  for update using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles_insert_self" on profiles
  for insert with check (id = auth.uid());

-- ---- classes ----
create policy "classes_select_member_teacher_admin" on classes
  for select using (
    teacher_id = auth.uid() or is_admin() or is_member_of_class(id)
  );
create policy "classes_write_teacher_admin" on classes
  for all using (teacher_id = auth.uid() or is_admin())
  with check (teacher_id = auth.uid() or is_admin());

-- ---- class_members ----
create policy "class_members_select" on class_members
  for select using (
    student_id = auth.uid() or is_admin() or is_teacher_of_class(class_id)
  );
create policy "class_members_write_teacher_admin" on class_members
  for all using (is_teacher_of_class(class_id) or is_admin())
  with check (is_teacher_of_class(class_id) or is_admin());

-- ---- lessons ----
create policy "lessons_select" on lessons
  for select using (
    is_admin() or is_teacher_of_class(class_id) or is_member_of_class(class_id)
  );
create policy "lessons_write_teacher_admin" on lessons
  for all using (is_teacher_of_class(class_id) or is_admin())
  with check (is_teacher_of_class(class_id) or is_admin());

-- ---- lesson_members ----
create policy "lesson_members_select" on lesson_members
  for select using (
    student_id = auth.uid() or is_admin() or
    exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  );
create policy "lesson_members_insert_self" on lesson_members
  for insert with check (
    student_id = auth.uid() and
    exists (
      select 1 from lessons l where l.id = lesson_id and l.status = 'live'
        and is_member_of_class(l.class_id)
    )
  );
create policy "lesson_members_update_self_or_teacher" on lesson_members
  for update using (
    student_id = auth.uid() or is_admin() or
    exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  );

-- ---- lesson_sessions ----
create policy "lesson_sessions_select" on lesson_sessions
  for select using (
    is_admin() or
    exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );
create policy "lesson_sessions_write_teacher_admin" on lesson_sessions
  for all using (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  ) with check (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  );

-- ---- materials ----
create policy "materials_select_owner_or_delivered_member" on materials
  for select using (
    owner_id = auth.uid() or is_admin() or
    exists (
      select 1 from lesson_materials lm join lessons l on l.id = lm.lesson_id
      where lm.material_id = materials.id and is_member_of_class(l.class_id)
    )
  );
create policy "materials_write_owner_admin" on materials
  for all using (owner_id = auth.uid() or is_admin())
  with check (owner_id = auth.uid() or is_admin());

-- ---- lesson_materials ----
create policy "lesson_materials_select" on lesson_materials
  for select using (
    is_admin() or
    exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );
create policy "lesson_materials_write_teacher_admin" on lesson_materials
  for all using (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  ) with check (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  );

-- ---- assignments ----
create policy "assignments_select" on assignments
  for select using (
    is_admin() or is_teacher_of_class(class_id) or is_member_of_class(class_id)
  );
create policy "assignments_write_teacher_admin" on assignments
  for all using (teacher_id = auth.uid() or is_admin())
  with check (teacher_id = auth.uid() or is_admin());

-- ---- assignment_submissions ----
create policy "submissions_select_own_or_teacher_admin" on assignment_submissions
  for select using (
    student_id = auth.uid() or is_admin() or
    exists (select 1 from assignments a where a.id = assignment_id and is_teacher_of_class(a.class_id))
  );
create policy "submissions_insert_own" on assignment_submissions
  for insert with check (
    student_id = auth.uid() and
    exists (select 1 from assignments a where a.id = assignment_id and is_member_of_class(a.class_id))
  );
create policy "submissions_update_own_or_teacher" on assignment_submissions
  for update using (
    student_id = auth.uid() or is_admin() or
    exists (select 1 from assignments a where a.id = assignment_id and is_teacher_of_class(a.class_id))
  );

-- ---- boards / board_cards ----
create policy "boards_select" on boards
  for select using (
    is_admin() or
    exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );
create policy "boards_write_teacher_admin" on boards
  for all using (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  ) with check (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and is_teacher_of_class(l.class_id))
  );

create policy "board_cards_select" on board_cards
  for select using (
    is_admin() or
    exists (
      select 1 from boards b join lessons l on l.id = b.lesson_id
      where b.id = board_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id))
    )
  );
create policy "board_cards_write_author_or_teacher" on board_cards
  for all using (
    author_id = auth.uid() or is_admin() or
    exists (select 1 from boards b join lessons l on l.id = b.lesson_id where b.id = board_id and is_teacher_of_class(l.class_id))
  ) with check (
    author_id = auth.uid() or is_admin() or
    exists (select 1 from boards b join lessons l on l.id = b.lesson_id where b.id = board_id and is_teacher_of_class(l.class_id))
  );

-- ---- comments / reactions ----
create policy "comments_select" on comments
  for select using (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );
create policy "comments_insert_member" on comments
  for insert with check (
    author_id = auth.uid() and
    exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );

create policy "reactions_select" on reactions
  for select using (
    is_admin() or exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );
create policy "reactions_insert_member" on reactions
  for insert with check (
    author_id = auth.uid() and
    exists (select 1 from lessons l where l.id = lesson_id and (is_teacher_of_class(l.class_id) or is_member_of_class(l.class_id)))
  );

-- ---- study_sessions / study_goals / homework ----
create policy "study_sessions_owner_or_admin" on study_sessions
  for all using (student_id = auth.uid() or is_admin())
  with check (student_id = auth.uid() or is_admin());

create policy "study_goals_owner_or_admin" on study_goals
  for all using (student_id = auth.uid() or is_admin())
  with check (student_id = auth.uid() or is_admin());

create policy "homework_owner_or_admin" on homework
  for all using (student_id = auth.uid() or is_admin())
  with check (student_id = auth.uid() or is_admin());

-- ---- reservation_slots / reservations ----
create policy "reservation_slots_select_all_authenticated" on reservation_slots
  for select using (auth.uid() is not null);
create policy "reservation_slots_write_teacher_admin" on reservation_slots
  for all using (
    is_admin() or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'teacher')
  ) with check (
    is_admin() or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'teacher')
  );

create policy "reservations_select_own_or_teacher_admin" on reservations
  for select using (
    student_id = auth.uid() or is_admin() or
    exists (select 1 from reservation_slots s where s.id = slot_id and s.created_by = auth.uid())
  );
create policy "reservations_insert_own" on reservations
  for insert with check (student_id = auth.uid());
create policy "reservations_update_own_or_admin" on reservations
  for update using (student_id = auth.uid() or is_admin());

-- ---- notifications ----
create policy "notifications_select_own" on notifications
  for select using (recipient_id = auth.uid() or is_admin());
create policy "notifications_update_own" on notifications
  for update using (recipient_id = auth.uid());
create policy "notifications_insert_system" on notifications
  for insert with check (true); -- サーバー側 (service role) からの挿入を想定

-- =========================================================
-- Realtime publication
-- =========================================================
alter publication supabase_realtime add table lessons;
alter publication supabase_realtime add table lesson_members;
alter publication supabase_realtime add table lesson_materials;
alter publication supabase_realtime add table assignment_submissions;
alter publication supabase_realtime add table board_cards;
alter publication supabase_realtime add table comments;
alter publication supabase_realtime add table reactions;

-- =========================================================
-- Storage buckets (実行後、Dashboardでも確認すること)
-- =========================================================
insert into storage.buckets (id, name, public)
values ('lesson-materials', 'lesson-materials', false)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('submissions', 'submissions', false)
on conflict (id) do nothing;

create policy "storage_materials_read" on storage.objects
  for select using (bucket_id = 'lesson-materials' and auth.uid() is not null);
create policy "storage_materials_write_teacher" on storage.objects
  for insert with check (
    bucket_id = 'lesson-materials' and
    exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('teacher','admin'))
  );

create policy "storage_submissions_read" on storage.objects
  for select using (bucket_id = 'submissions' and auth.uid() is not null);
create policy "storage_submissions_write_own" on storage.objects
  for insert with check (bucket_id = 'submissions' and auth.uid() is not null);
