-- QUL Study PLUS+ MVP tables. These are namespaced to preserve the existing QUL Study schema.
create table public.sp_lessons (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '',
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled','live','completed','cancelled')),
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create table public.sp_lesson_enrollments (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.sp_lessons(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz,
  left_at timestamptz,
  created_at timestamptz not null default now(),
  unique (lesson_id, student_id)
);
create table public.sp_assignments (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid references public.sp_lessons(id) on delete set null,
  title text not null check (char_length(title) between 1 and 120),
  instructions text not null default '',
  due_at timestamptz,
  status text not null default 'published' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.sp_assignment_submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.sp_assignments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  submission_text text not null default '',
  submitted_at timestamptz,
  feedback text,
  graded_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (assignment_id, student_id)
);
create table public.sp_study_logs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null,
  minutes integer not null check (minutes between 1 and 1440),
  note text not null default '',
  studied_on date not null default current_date,
  created_at timestamptz not null default now()
);
create table public.sp_materials (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '',
  url text not null check (url ~ '^https?://'),
  created_at timestamptz not null default now()
);
create index sp_lessons_teacher_starts_idx on public.sp_lessons(teacher_id, starts_at);
create index sp_enrollments_student_idx on public.sp_lesson_enrollments(student_id, created_at desc);
create index sp_assignments_teacher_due_idx on public.sp_assignments(teacher_id, due_at);
create index sp_submissions_student_updated_idx on public.sp_assignment_submissions(student_id, updated_at desc);
create index sp_study_logs_student_date_idx on public.sp_study_logs(student_id, studied_on desc);
create index sp_materials_teacher_created_idx on public.sp_materials(teacher_id, created_at desc);

alter table public.sp_lessons enable row level security;
alter table public.sp_lesson_enrollments enable row level security;
alter table public.sp_assignments enable row level security;
alter table public.sp_assignment_submissions enable row level security;
alter table public.sp_study_logs enable row level security;
alter table public.sp_materials enable row level security;

create policy sp_lessons_read_scheduled_or_own on public.sp_lessons for select to authenticated using (status in ('scheduled','live') or teacher_id=(select auth.uid()));
create policy sp_lessons_teacher_insert on public.sp_lessons for insert to authenticated with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_lessons_teacher_update on public.sp_lessons for update to authenticated using (teacher_id=(select auth.uid())) with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_lessons_teacher_delete on public.sp_lessons for delete to authenticated using (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));

create policy sp_enrollments_read_participants on public.sp_lesson_enrollments for select to authenticated using (student_id=(select auth.uid()) or exists(select 1 from public.sp_lessons l where l.id=lesson_id and l.teacher_id=(select auth.uid())));
create policy sp_students_enroll_self on public.sp_lesson_enrollments for insert to authenticated with check (student_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='student') and exists(select 1 from public.sp_lessons l where l.id=lesson_id and l.status='scheduled'));
create policy sp_students_cancel_own_enrollment on public.sp_lesson_enrollments for delete to authenticated using (student_id=(select auth.uid()));
create policy sp_teachers_update_enrollment on public.sp_lesson_enrollments for update to authenticated using (exists(select 1 from public.sp_lessons l where l.id=lesson_id and l.teacher_id=(select auth.uid()))) with check (exists(select 1 from public.sp_lessons l where l.id=lesson_id and l.teacher_id=(select auth.uid())));

create policy sp_assignments_read_published_or_own on public.sp_assignments for select to authenticated using (status='published' or teacher_id=(select auth.uid()));
create policy sp_assignments_teacher_insert on public.sp_assignments for insert to authenticated with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_assignments_teacher_update on public.sp_assignments for update to authenticated using (teacher_id=(select auth.uid())) with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_assignments_teacher_delete on public.sp_assignments for delete to authenticated using (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));

create policy sp_submissions_read_student_or_teacher on public.sp_assignment_submissions for select to authenticated using (student_id=(select auth.uid()) or exists(select 1 from public.sp_assignments a where a.id=assignment_id and a.teacher_id=(select auth.uid())));
create policy sp_students_submit_own on public.sp_assignment_submissions for insert to authenticated with check (student_id=(select auth.uid()) and exists(select 1 from public.sp_assignments a where a.id=assignment_id and a.status='published'));
create policy sp_students_update_own_ungraded on public.sp_assignment_submissions for update to authenticated using (student_id=(select auth.uid()) and graded_at is null) with check (student_id=(select auth.uid()) and graded_at is null);
create policy sp_teachers_grade_submissions on public.sp_assignment_submissions for update to authenticated using (exists(select 1 from public.sp_assignments a where a.id=assignment_id and a.teacher_id=(select auth.uid()))) with check (exists(select 1 from public.sp_assignments a where a.id=assignment_id and a.teacher_id=(select auth.uid())));

create policy sp_study_logs_read_own on public.sp_study_logs for select to authenticated using (student_id=(select auth.uid()));
create policy sp_study_logs_insert_own on public.sp_study_logs for insert to authenticated with check (student_id=(select auth.uid()));
create policy sp_study_logs_update_own on public.sp_study_logs for update to authenticated using (student_id=(select auth.uid())) with check (student_id=(select auth.uid()));
create policy sp_study_logs_delete_own on public.sp_study_logs for delete to authenticated using (student_id=(select auth.uid()));

create policy sp_materials_read_authenticated on public.sp_materials for select to authenticated using (true);
create policy sp_materials_teacher_insert on public.sp_materials for insert to authenticated with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_materials_teacher_update on public.sp_materials for update to authenticated using (teacher_id=(select auth.uid())) with check (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
create policy sp_materials_teacher_delete on public.sp_materials for delete to authenticated using (teacher_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role in ('teacher','admin')));
