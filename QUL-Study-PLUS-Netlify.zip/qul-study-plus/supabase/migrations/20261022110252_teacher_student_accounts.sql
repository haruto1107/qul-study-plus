-- Teacher-managed student accounts. Run after 202610210001_initial_schema.sql.
create table public.teacher_students (
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (teacher_id, student_id),
  constraint teacher_students_not_self check (teacher_id <> student_id)
);

create index teacher_students_student_idx on public.teacher_students (student_id, created_at desc);
alter table public.teacher_students enable row level security;

create policy "teachers_read_their_student_links"
on public.teacher_students for select to authenticated
using (teacher_id = (select auth.uid()) or student_id = (select auth.uid()));

create policy "teachers_link_their_students"
on public.teacher_students for insert to authenticated
with check (
  teacher_id = (select auth.uid())
  and exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role in ('teacher', 'admin'))
  and exists (select 1 from public.profiles s where s.id = student_id and s.role = 'student')
);

create policy "teachers_unlink_their_students"
on public.teacher_students for delete to authenticated
using (teacher_id = (select auth.uid()) and exists (
  select 1 from public.profiles p where p.id = (select auth.uid()) and p.role in ('teacher', 'admin')
));

create policy "teachers_read_linked_student_profiles"
on public.profiles for select to authenticated
using (
  id = (select auth.uid())
  or exists (
    select 1 from public.teacher_students ts
    where ts.teacher_id = (select auth.uid()) and ts.student_id = profiles.id
  )
);

comment on table public.teacher_students is 'Links teacher-issued student accounts to the teacher who created them.';
