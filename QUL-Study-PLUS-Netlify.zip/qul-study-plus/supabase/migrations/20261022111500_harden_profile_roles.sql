-- Prevent a normal authenticated user from granting themselves teacher/admin privileges.
-- Trusted server-side provisioning (service role) may set roles when auth.uid() is NULL.
create or replace function public.prevent_profile_role_escalation()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if auth.uid() is not null and new.role is distinct from old.role then
    raise exception 'Profile role changes require trusted administrator provisioning.';
  end if;
  return new;
end;
$$;

drop trigger if exists prevent_profile_role_escalation on public.profiles;
create trigger prevent_profile_role_escalation
before update of role on public.profiles
for each row execute function public.prevent_profile_role_escalation();

drop policy if exists profiles_insert_self on public.profiles;
create policy profiles_insert_self
on public.profiles for insert to authenticated
with check (id = (select auth.uid()) and role = 'student'::public.user_role);

comment on function public.prevent_profile_role_escalation() is
'Prevents authenticated users from changing their own profile role; trusted server-side provisioning may set roles.';
