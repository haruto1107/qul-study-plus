import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !anonKey || !serviceRoleKey) {
    return json({ error: 'サーバー設定が不足しています。管理者に連絡してください。' }, 500);
  }

  const authorization = req.headers.get('Authorization');
  if (!authorization) return json({ error: 'ログインが必要です。' }, 401);
  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: userResult, error: userError } = await userClient.auth.getUser();
  if (userError || !userResult.user) return json({ error: 'ログイン状態を確認できません。再ログインしてください。' }, 401);

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: teacher, error: teacherError } = await admin.from('profiles')
    .select('id, role').eq('id', userResult.user.id).maybeSingle();
  if (teacherError || !teacher || !['teacher', 'admin'].includes(teacher.role)) {
    return json({ error: '生徒アカウントを発行できる先生権限がありません。' }, 403);
  }

  let body: { displayName?: unknown; email?: unknown };
  try { body = await req.json(); } catch { return json({ error: '入力内容を読み取れません。' }, 400); }
  const displayName = typeof body.displayName === 'string' ? body.displayName.trim() : '';
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  if (!displayName || displayName.length > 80) return json({ error: '生徒の名前を1〜80文字で入力してください。' }, 400);
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: '有効なメールアドレスを入力してください。' }, 400);

  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@$%';
  const bytes = new Uint8Array(20);
  crypto.getRandomValues(bytes);
  const temporaryPassword = Array.from(bytes, b => alphabet[b % alphabet.length]).join('');
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email, password: temporaryPassword, email_confirm: true,
    user_metadata: { display_name: displayName },
  });
  if (createError || !created.user) {
    const message = createError?.message.toLowerCase().includes('already')
      ? 'このメールアドレスはすでに登録されています。'
      : 'アカウントを作成できませんでした。入力内容を確認してください。';
    return json({ error: message }, 400);
  }

  const studentId = created.user.id;
  const { error: profileError } = await admin.from('profiles').insert({
    id: studentId, display_name: displayName, role: 'student',
  });
  if (profileError) {
    await admin.auth.admin.deleteUser(studentId);
    return json({ error: '生徒プロフィールを作成できませんでした。管理者に連絡してください。' }, 500);
  }
  const { error: linkError } = await admin.from('teacher_students').insert({ teacher_id: teacher.id, student_id: studentId });
  if (linkError) {
    await admin.from('profiles').delete().eq('id', studentId);
    await admin.auth.admin.deleteUser(studentId);
    return json({ error: '先生と生徒の紐付けに失敗しました。管理者に連絡してください。' }, 500);
  }

  return json({ displayName, email, temporaryPassword });
});
