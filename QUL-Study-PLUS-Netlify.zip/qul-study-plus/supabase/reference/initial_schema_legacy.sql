-- QUL Study PLUS+ initial schema
-- Apply in a Supabase SQL editor after reviewing. Every exposed table has RLS enabled.
create extension if not exists pgcrypto;

create type public.study_role as enum ('student', 'teacher', 'admin');
create type public.lesson_status as enum ('scheduled', 'live', 'completed', 'cancelled');
create type public.assignment_status as enum ('draft', 'published', 'archived');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role public.study_role not null default 'student',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete restrict,
  title text not null,
  description text not null default '',
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status public.lesson_status not null default 'scheduled',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint lessons_valid_time check (ends_at > starts_at)
);

create table public.lesson_enrollments (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz,
  left_at timestamptz,
  created_at timestamptz not null default now(),
  unique (lesson_id, student_id)
);

create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete restrict,
  lesson_id uuid references public.lessons(id) on delete set null,
  title text not null,
  instructions text not null default '',
  due_at timestamptz,
  status public.assignment_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.assignment_submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  submission_text text not null default '',
  file_path text,
  submitted_at timestamptz,
  feedback text,
  graded_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (assignment_id, student_id)
);

create table public.study_logs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null,
  minutes integer not null check (minutes between 1 and 1440),
  note text not null default '',
  studied_on date not null default current_date,
  created_at timestamptz not null default now()
);

create index lessons_teacher_starts_idx on public.lessons (teacher_id, starts_at);
create index lesson_enrollments_student_idx on public.lesson_enrollments (student_id, created_at desc);
create index assignments_teacher_due_idx on public.assignments (teacher_id, due_at);
create index assignment_submissions_student_idx on public.assignment_submissions (student_id, updated_at desc);
create index study_logs_student_date_idx on public.study_logs (student_id, studied_on desc);

alter table public.profiles enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_enrollments enable row level security;
alter table public.assignments enable row level security;
alter table public.assignment_submissions enable row level security;
alter table public.study_logs enable row level security;

-- A profile can be read by its owner. Admin provisioning/management policies are intentionally deferred.
create policy "profiles_read_self" on public.profiles for select to authenticated using ((select auth.uid()) = id);
-- Users may edit their own profile, but role changes require a trusted admin workflow.
create function public.prevent_self_role_change() returns trigger
language plpgsql set search_path = '' as $$
begin
  if new.role is distinct from old.role then
    raise exception 'Profile role changes must use the trusted admin workflow.';
  end if;
  return new;
end;
$$;
create trigger profiles_prevent_role_change
before update on public.profiles
for each row execute function public.prevent_self_role_change();
create policy "profiles_update_self" on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

-- Authenticated users may see scheduled/live lessons; teachers may manage only their own lessons.
create policy "lessons_read_scheduled_or_own" on public.lessons for select to authenticated using (status in ('scheduled','live') or teacher_id = (select auth.uid()));
create policy "lessons_teacher_insert" on public.lessons for insert to authenticated with check (teacher_id = (select auth.uid()) and exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role in ('teacher','admin')));
create policy "lessons_teacher_update" on public.lessons for update to authenticated using (teacher_id = (select auth.uid())) with check (teacher_id = (select auth.uid()));
create policy "lessons_teacher_delete" on public.lessons for delete to authenticated using (teacher_id = (select auth.uid()));

create policy "enrollments_read_participants" on public.lesson_enrollments for select to authenticated using (student_id = (select auth.uid()) or exists (select 1 from public.lessons l where l.id = lesson_id and l.teacher_id = (select auth.uid())));
create policy "students_enroll_self" on public.lesson_enrollments for insert to authenticated with check (student_id = (select auth.uid()) and exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'student') and exists (select 1 from public.lessons l where l.id = lesson_id and l.status = 'scheduled'));
create policy "students_cancel_own_enrollment" on public.lesson_enrollments for delete to authenticated using (student_id = (select auth.uid()));
create policy "teachers_update_enrollment" on public.lesson_enrollments for update to authenticated using (exists (select 1 from public.lessons l where l.id = lesson_id and l.teacher_id = (select auth.uid()))) with check (exists (select 1 from public.lessons l where l.id = lesson_id and l.teacher_id = (select auth.uid())));

create policy "assignments_read_published_or_own" on public.assignments for select to authenticated using (status = 'published' or teacher_id = (select auth.uid()));
create policy "assignments_teacher_insert" on public.assignments for insert to authenticated with check (teacher_id = (select auth.uid()) and exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role in ('teacher','admin')));
create policy "assignments_teacher_update" on public.assignments for update to authenticated using (teacher_id = (select auth.uid())) with check (teacher_id = (select auth.uid()));
create policy "assignments_teacher_delete" on public.assignments for delete to authenticated using (teacher_id = (select auth.uid()));

create policy "submissions_read_student_or_teacher" on public.assignment_submissions for select to authenticated using (student_id = (select auth.uid()) or exists (select 1 from public.assignments a where a.id = assignment_id and a.teacher_id = (select auth.uid())));
create policy "students_submit_own" on public.assignment_submissions for insert to authenticated with check (student_id = (select auth.uid()) and exists (select 1 from public.assignments a where a.id = assignment_id and a.status = 'published'));
create policy "students_update_own_ungraded" on public.assignment_submissions for update to authenticated using (student_id = (select auth.uid()) and graded_at is null) with check (student_id = (select auth.uid()) and graded_at is null);
create policy "teachers_grade_submissions" on public.assignment_submissions for update to authenticated using (exists (select 1 from public.assignments a where a.id = assignment_id and a.teacher_id = (select auth.uid()))) with check (exists (select 1 from public.assignments a where a.id = assignment_id and a.teacher_id = (select auth.uid())));

create policy "study_logs_read_own" on public.study_logs for select to authenticated using (student_id = (select auth.uid()));
create policy "study_logs_insert_own" on public.study_logs for insert to authenticated with check (student_id = (select auth.uid()));
create policy "study_logs_update_own" on public.study_logs for update to authenticated using (student_id = (select auth.uid())) with check (student_id = (select auth.uid()));
create policy "study_logs_delete_own" on public.study_logs for delete to authenticated using (student_id = (select auth.uid()));

-- Profile creation trigger intentionally omitted: role must be provisioned by a trusted admin workflow,
-- not copied from user-controlled auth metadata.
