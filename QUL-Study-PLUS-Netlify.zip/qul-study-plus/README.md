# QUL Study PLUS+

QUL Study PLUS+ is a Japanese learning portal using Next.js, Supabase Auth/Postgres, and Netlify static hosting.

## Implemented MVP features
- Email/password login; user role comes from the protected `profiles.role` record
- Teacher/student workspace separation
- Teachers create student accounts via a secured Supabase Edge Function
- Teacher-created assignments; students submit and update text responses
- Lesson scheduling and student reservations; teachers can start/end a lesson status
- Student study-time logs
- Teacher-managed learning-material links
- Row Level Security on the new `sp_*` tables
- Role-escalation protection: self-service profile inserts are restricted to `student`, and authenticated users cannot change their own role
- Responsive UI in QUL brand color `#809CCF`

## Current limits
- Live video calls and screen sharing are not implemented. The lesson flow currently supports scheduling, booking, and start/end status only.
- Materials are URLs, not uploaded files.
- The first teacher account still needs to be provisioned by a trusted administrator in Supabase Auth + `public.profiles`. Never let public sign-up choose a teacher role.
- The front-end build could not be verified in this environment because the npm registry was unreachable. Test the deployed build and use separate teacher/student accounts before real classroom data is entered.

## Supabase project already configured
The connected Supabase project is `qul-study-plus` (`bnixurbnxnqqtxrmqkmv`). The following changes have been applied to it:
- `teacher_student_accounts` — secure teacher/student relationship table and policies
- `studyplus_mvp` — namespaced MVP tables and RLS policies
- `harden_profile_roles` — prevents users from self-assigning teacher/admin roles
- Edge Function `create-student-account` deployed with JWT verification enabled

The existing database already contained QUL Study tables with different column definitions. To avoid overwriting them, this MVP uses `sp_lessons`, `sp_lesson_enrollments`, `sp_assignments`, `sp_assignment_submissions`, `sp_study_logs`, and `sp_materials`. `supabase/reference/initial_schema_legacy.sql` is a historical bootstrap reference and must not be applied to the existing project.

## Netlify
- Existing project: `qul-study-plus`
- Build command: `npm run build`
- Publish directory: `out`
- Node.js: 22
- `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` have been configured on the Netlify project.

The Netlify site itself has **not yet been published**. The available Netlify connection can configure the project and environment variables but does not expose a deploy/upload action, and this environment cannot reach the npm registry. A successful production deploy and browser smoke test are still required.

## Local development

```bash
cp .env.example .env.local
npm install
npm run dev
```
