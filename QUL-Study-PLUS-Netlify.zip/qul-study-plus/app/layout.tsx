import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'QUL Study PLUS+ | 学びを、もっとつなぐ。',
  description: '授業・課題・教材・学習記録をひとつにつなぐ学習プラットフォーム。',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ja"><body>{children}</body></html>;
}
