'use client';

import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, CheckCircle2, Copy, KeyRound, LoaderCircle, Mail, ShieldCheck, UserPlus, Users } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

export default function TeacherStudentsPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [created, setCreated] = useState<{ name: string; email: string; temporaryPassword: string } | null>(null);
  const [copied, setCopied] = useState(false);

  async function createStudent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(''); setCreated(null); setCopied(false);
    try {
      const supabase = createClient();
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('先に先生アカウントでログインしてください。');
      const { data, error: invokeError } = await supabase.functions.invoke('create-student-account', {
        body: { displayName: name.trim(), email: email.trim() },
      });
      if (invokeError) throw new Error(invokeError.message || '生徒アカウントを作成できませんでした。');
      if (data?.error) throw new Error(data.error);
      setCreated({ name: data.displayName, email: data.email, temporaryPassword: data.temporaryPassword });
      setName(''); setEmail('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'エラーが発生しました。');
    } finally { setBusy(false); }
  }

  async function copyCredentials() {
    if (!created) return;
    const text = `QUL Study PLUS+ 生徒アカウント\n名前：${created.name}\nログインメール：${created.email}\n初期パスワード：${created.temporaryPassword}\n初回ログイン後はパスワードを変更してください。`;
    try { await navigator.clipboard.writeText(text); setCopied(true); }
    catch { setError('コピーできませんでした。表示中の初期パスワードを手動で控えてください。'); }
  }

  return <main className="teacher-page">
    <header className="teacher-header">
      <Link href="/" className="back-link"><ArrowLeft size={16}/> ホームへ戻る</Link>
      <span className="teacher-brand"><span className="brand-mark">Q</span> QUL Study <b>PLUS+</b></span>
    </header>
    <div className="teacher-content">
      <div className="teacher-eyebrow"><ShieldCheck size={15}/> TEACHER WORKSPACE</div>
      <h1>生徒アカウント管理</h1>
      <p className="teacher-intro">先生が生徒アカウントを発行し、ログイン情報を本人に渡します。</p>

      <section className="teacher-info-grid">
        <article className="teacher-info-card"><span className="teacher-info-icon"><UserPlus size={20}/></span><div><b>先生が発行</b><p>生徒が自分で先生権限を選ぶことはできません。</p></div></article>
        <article className="teacher-info-card"><span className="teacher-info-icon"><KeyRound size={20}/></span><div><b>初期パスワード</b><p>自動生成し、作成直後に一度だけ表示します。</p></div></article>
      </section>

      <section className="teacher-form-card">
        <div className="teacher-card-heading"><div className="teacher-heading-icon"><Users size={20}/></div><div><h2>新しい生徒を登録</h2><p>生徒の名前とログイン用メールアドレスを入力</p></div></div>
        <form onSubmit={createStudent} className="student-create-form">
          <label>生徒の名前<input value={name} onChange={e => setName(e.target.value)} required maxLength={80} placeholder="例：山田 太郎" autoComplete="name" /></label>
          <label>ログイン用メールアドレス<input value={email} onChange={e => setEmail(e.target.value)} required type="email" maxLength={254} placeholder="student@example.com" autoComplete="email" /></label>
          <button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17}/> : <UserPlus size={17}/>} {busy ? '作成中…' : '生徒アカウントを発行'}</button>
        </form>
        {error && <p className="teacher-error" role="alert">{error}</p>}
        {created && <section className="credentials-card" aria-live="polite">
          <div className="credentials-title"><CheckCircle2 size={19}/><div><b>アカウントを作成しました</b><p>この情報を生徒本人に安全な方法で渡してください。</p></div></div>
          <dl><dt>生徒名</dt><dd>{created.name}</dd><dt>ログインメール</dt><dd>{created.email}</dd><dt>初期パスワード</dt><dd className="temporary-password">{created.temporaryPassword}</dd></dl>
          <button className="secondary-button copy-button" type="button" onClick={copyCredentials}><Copy size={15}/>{copied ? 'コピーしました' : 'ログイン情報をコピー'}</button>
          <p className="credential-warning"><ShieldCheck size={14}/> 初期パスワードは画面を閉じる前に控えてください。チャットや公開場所には貼り付けないでください。</p>
        </section>}
      </section>
      <p className="teacher-footnote"><Mail size={15}/> 実際に利用するには、Supabaseの設定と先生アカウントへの権限付与が必要です。</p>
      <footer>Copyright © 2026 QUL Group. All Rights Reserved.</footer>
    </div>
  </main>;
}
