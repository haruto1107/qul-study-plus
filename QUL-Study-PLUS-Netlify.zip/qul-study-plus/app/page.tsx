'use client';

import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowRight, BookOpen, CalendarDays, CheckCircle2, Clock3, FileText, GraduationCap, LayoutDashboard, LogOut, Plus, RefreshCw, ShieldCheck, Users, Video, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

type Profile = { id: string; display_name: string; role: 'student' | 'teacher' | 'admin' };
type Assignment = { id: string; teacher_id: string; title: string; instructions: string; due_at: string | null; status: 'draft' | 'published' | 'archived'; created_at: string };
type Submission = { id: string; assignment_id: string; student_id: string; submission_text: string; submitted_at: string | null; feedback: string | null; graded_at: string | null };
type Lesson = { id: string; teacher_id: string; title: string; description: string; starts_at: string; ends_at: string; status: 'scheduled' | 'live' | 'completed' | 'cancelled' };
type StudyLog = { id: string; subject: string; minutes: number; note: string; studied_on: string };
type Enrollment = { id: string; lesson_id: string; student_id: string; joined_at: string | null };
type Material = { id: string; teacher_id: string; title: string; description: string; url: string; created_at: string };
type Section = 'home' | 'lessons' | 'tasks' | 'study' | 'materials' | 'students';

const sections: { id: Section; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'home', label: 'ホーム', icon: LayoutDashboard },
  { id: 'lessons', label: '授業・予約', icon: Video },
  { id: 'tasks', label: '課題', icon: CheckCircle2 },
  { id: 'study', label: '学習記録', icon: Clock3 },
  { id: 'materials', label: '教材', icon: BookOpen },
];

export default function Home() {
  const [supabase] = useState(() => createClient());
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [busy, setBusy] = useState(false);
  const [section, setSection] = useState<Section>('home');
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [logs, setLogs] = useState<StudyLog[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [notice, setNotice] = useState('');
  const [showAssignmentForm, setShowAssignmentForm] = useState(false);
  const [showLessonForm, setShowLessonForm] = useState(false);
  const [showLogForm, setShowLogForm] = useState(false);
  const [showMaterialForm, setShowMaterialForm] = useState(false);
  const [assignmentTitle, setAssignmentTitle] = useState('');
  const [assignmentInstructions, setAssignmentInstructions] = useState('');
  const [assignmentDue, setAssignmentDue] = useState('');
  const [lessonTitle, setLessonTitle] = useState('');
  const [lessonDescription, setLessonDescription] = useState('');
  const [lessonStarts, setLessonStarts] = useState('');
  const [lessonEnds, setLessonEnds] = useState('');
  const [logSubject, setLogSubject] = useState('数学');
  const [logMinutes, setLogMinutes] = useState('30');
  const [logNote, setLogNote] = useState('');
  const [materialTitle, setMaterialTitle] = useState('');
  const [materialDescription, setMaterialDescription] = useState('');
  const [materialUrl, setMaterialUrl] = useState('');
  const [submissionDrafts, setSubmissionDrafts] = useState<Record<string, string>>({});

  const loadProfile = useCallback(async (userId: string) => {
    const { data, error } = await supabase.from('profiles').select('id,display_name,role').eq('id', userId).maybeSingle();
    if (error) throw error;
    setProfile(data as Profile | null);
  }, [supabase]);

  const refreshData = useCallback(async (current: Profile) => {
    setNotice('');
    const [a, l, s, e, logsResult, m] = await Promise.all([
      supabase.from('sp_assignments').select('*').order('created_at', { ascending: false }),
      supabase.from('sp_lessons').select('*').order('starts_at', { ascending: true }),
      supabase.from('sp_assignment_submissions').select('*').order('updated_at', { ascending: false }),
      supabase.from('sp_lesson_enrollments').select('*'),
      supabase.from('sp_study_logs').select('*').order('studied_on', { ascending: false }).limit(30),
      supabase.from('sp_materials').select('*').order('created_at', { ascending: false }),
    ]);
    const firstError = [a.error, l.error, s.error, e.error, logsResult.error, m.error].find(Boolean);
    if (firstError) throw firstError;
    setAssignments((a.data ?? []) as Assignment[]);
    setLessons((l.data ?? []) as Lesson[]);
    setSubmissions((s.data ?? []) as Submission[]);
    setEnrollments((e.data ?? []) as Enrollment[]);
    setLogs((logsResult.data ?? []) as StudyLog[]);
    setMaterials((m.data ?? []) as Material[]);
    if (current.role === 'student') {
      const draftMap: Record<string, string> = {};
      (s.data ?? []).filter((x: Submission) => x.student_id === current.id).forEach((x: Submission) => { draftMap[x.assignment_id] = x.submission_text; });
      setSubmissionDrafts(draftMap);
    }
  }, [supabase]);

  const syncSession = useCallback(async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await loadProfile(session.user.id);
      } else setProfile(null);
    } catch (e) { setAuthError(e instanceof Error ? e.message : 'アカウント情報を読み込めませんでした。'); }
    finally { setLoading(false); }
  }, [loadProfile, supabase]);

  useEffect(() => {
    void syncSession();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) { void loadProfile(session.user.id).catch(e => setAuthError(e.message)); }
      else setProfile(null);
    });
    return () => subscription.unsubscribe();
  }, [supabase, syncSession, loadProfile]);

  useEffect(() => {
    if (!profile) return;
    void refreshData(profile).catch(e => setNotice(`データを読み込めませんでした：${e.message || '設定を確認してください。'}`));
  }, [profile, refreshData]);

  const isTeacher = profile?.role === 'teacher' || profile?.role === 'admin';
  const weeklyMinutes = useMemo(() => logs.reduce((sum, item) => sum + (item.minutes || 0), 0), [logs]);
  const mySubmissions = submissions.filter(s => s.student_id === profile?.id);
  const myEnrollments = enrollments.filter(e => e.student_id === profile?.id);
  const myLessons = isTeacher ? lessons.filter(l => l.teacher_id === profile?.id) : lessons.filter(l => myEnrollments.some(e => e.lesson_id === l.id));

  async function signIn(event: FormEvent) {
    event.preventDefault(); setBusy(true); setAuthError('');
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw error;
      setPassword('');
      await syncSession();
    } catch (e) { setAuthError(e instanceof Error ? e.message : 'ログインできませんでした。'); }
    finally { setBusy(false); }
  }

  async function signOut() { await supabase.auth.signOut(); setProfile(null); setSection('home'); }
  async function reload() { if (!profile) return; try { await refreshData(profile); setNotice('最新データに更新しました。'); } catch (e) { setNotice(e instanceof Error ? e.message : '更新に失敗しました。'); } }
  async function createAssignment(event: FormEvent) {
    event.preventDefault(); if (!profile) return; setBusy(true);
    try {
      const { error } = await supabase.from('sp_assignments').insert({ teacher_id: profile.id, title: assignmentTitle.trim(), instructions: assignmentInstructions.trim(), due_at: assignmentDue ? new Date(assignmentDue).toISOString() : null, status: 'published' });
      if (error) throw error;
      setAssignmentTitle(''); setAssignmentInstructions(''); setAssignmentDue(''); setShowAssignmentForm(false); await refreshData(profile); setNotice('課題を公開しました。');
    } catch (e) { setNotice(`課題を作成できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }
  async function saveSubmission(assignmentId: string) {
    if (!profile) return; setBusy(true);
    try {
      const existing = mySubmissions.find(s => s.assignment_id === assignmentId);
      const payload = { assignment_id: assignmentId, student_id: profile.id, submission_text: submissionDrafts[assignmentId] || '', submitted_at: new Date().toISOString() };
      const result = existing ? await supabase.from('sp_assignment_submissions').update(payload).eq('id', existing.id) : await supabase.from('sp_assignment_submissions').insert(payload);
      if (result.error) throw result.error;
      await refreshData(profile); setNotice('課題を提出しました。');
    } catch (e) { setNotice(`提出できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }
  async function createLesson(event: FormEvent) {
    event.preventDefault(); if (!profile) return; setBusy(true);
    try {
      const { error } = await supabase.from('sp_lessons').insert({ teacher_id: profile.id, title: lessonTitle.trim(), description: lessonDescription.trim(), starts_at: new Date(lessonStarts).toISOString(), ends_at: new Date(lessonEnds).toISOString(), status: 'scheduled' });
      if (error) throw error;
      setLessonTitle(''); setLessonDescription(''); setLessonStarts(''); setLessonEnds(''); setShowLessonForm(false); await refreshData(profile); setNotice('授業を登録しました。');
    } catch (e) { setNotice(`授業を登録できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }
  async function enroll(lessonId: string) {
    if (!profile) return; setBusy(true);
    try { const { error } = await supabase.from('sp_lesson_enrollments').insert({ lesson_id: lessonId, student_id: profile.id }); if (error) throw error; await refreshData(profile); setNotice('授業を予約しました。'); }
    catch (e) { setNotice(`予約できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }
  async function updateLessonStatus(lesson: Lesson, status: Lesson['status']) {
    if (!profile) return;
    try { const { error } = await supabase.from('sp_lessons').update({ status }).eq('id', lesson.id); if (error) throw error; await refreshData(profile); setNotice(status === 'live' ? '授業を開始しました。' : status === 'completed' ? '授業を終了しました。' : '授業を更新しました。'); }
    catch (e) { setNotice(`授業を更新できませんでした：${(e as Error).message}`); }
  }
  async function createStudyLog(event: FormEvent) {
    event.preventDefault(); if (!profile) return; setBusy(true);
    try { const { error } = await supabase.from('sp_study_logs').insert({ student_id: profile.id, subject: logSubject, minutes: Number(logMinutes), note: logNote.trim() }); if (error) throw error; setLogNote(''); setShowLogForm(false); await refreshData(profile); setNotice('学習記録を保存しました。'); }
    catch (e) { setNotice(`記録できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }
  async function createMaterial(event: FormEvent) {
    event.preventDefault(); if (!profile) return; setBusy(true);
    try { const { error } = await supabase.from('sp_materials').insert({ teacher_id: profile.id, title: materialTitle.trim(), description: materialDescription.trim(), url: materialUrl.trim() }); if (error) throw error; setMaterialTitle(''); setMaterialDescription(''); setMaterialUrl(''); setShowMaterialForm(false); await refreshData(profile); setNotice('教材リンクを登録しました。'); }
    catch (e) { setNotice(`教材を登録できませんでした：${(e as Error).message}`); }
    finally { setBusy(false); }
  }

  if (loading) return <main className="auth-screen"><div className="auth-card"><span className="brand-mark">Q</span><h1>QUL Study PLUS+</h1><p>アカウントを確認しています…</p></div></main>;

  if (!profile) return <main className="auth-screen"><section className="auth-card"><div className="auth-logo"><span className="brand-mark">Q</span></div><div className="eyebrow">LEARNING SPACE</div><h1>QUL Study <span>PLUS+</span></h1><p className="auth-subtitle">学びを、もっとつなぐ。</p><form onSubmit={signIn} className="auth-form"><label>メールアドレス<input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" required placeholder="you@example.com" /></label><label>パスワード<input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required placeholder="パスワード" /></label><button className="primary-button full-button" type="submit" disabled={busy}>{busy ? 'ログイン中…' : 'ログイン'} <ArrowRight size={17}/></button></form>{authError && <p className="error-message" role="alert">{authError}</p>}<div className="auth-help"><ShieldCheck size={17}/><p>アカウントは先生または管理者から発行されます。新規登録ボタンはありません。</p></div><footer>Copyright © 2026 QUL Group. All Rights Reserved.</footer></section></main>;

  if (!profile.role) return <main className="auth-screen"><section className="auth-card"><h1>アカウントを準備中</h1><p>このアカウントの役割が設定されていません。管理者に確認してください。</p><button className="secondary-button" onClick={signOut}>ログアウト</button></section></main>;

  const pageTitle = sections.find(s => s.id === section)?.label || (section === 'students' ? '生徒管理' : 'ホーム');
  const availableAssignments = assignments.filter(a => isTeacher ? a.teacher_id === profile.id : a.status === 'published');
  const availableLessons = lessons.filter(l => isTeacher ? l.teacher_id === profile.id : l.status === 'scheduled' || myEnrollments.some(e => e.lesson_id === l.id));
  return <main className="app-shell">
    <aside className="sidebar"><a className="brand" href="#home" onClick={e => {e.preventDefault();setSection('home')}}><span className="brand-mark">Q</span><span><b>QUL Study</b><small>PLUS+</small></span></a><div className="workspace-label">LEARNING SPACE</div><nav className="nav-list" aria-label="メインメニュー">{sections.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${section === item.id ? 'active' : ''}`} onClick={() => setSection(item.id)}><Icon size={18}/>{item.label}</button>; })}{isTeacher && <button className={`nav-item ${section === 'students' ? 'active' : ''}`} onClick={() => window.location.assign('/teacher/students/')}><Users size={18}/>生徒管理</button>}</nav><div className="sidebar-bottom"><div className="help-card"><GraduationCap size={17}/><b>学びを、もっと。</b><p>毎日の一歩を、未来の力に。</p></div><div className="profile"><div className="avatar">{profile.display_name.slice(0,1) || 'Q'}</div><div><b>{profile.display_name || 'QULユーザー'}</b><small>{isTeacher ? '先生アカウント' : '生徒アカウント'}</small></div><button className="icon-button" title="ログアウト" onClick={signOut}><LogOut size={17}/></button></div></div></aside>
    <section className="main-area"><header className="topbar"><div className="breadcrumb">QUL Study PLUS+ <span>/</span> {pageTitle}</div><div className="topbar-right"><span className="live-pill"><span/> 接続中</span><button className="icon-button" title="更新" onClick={() => void reload()}><RefreshCw size={17}/></button><div className="avatar small">{profile.display_name.slice(0,1) || 'Q'}</div></div></header>
      <div className="content"><section className="welcome-row"><div><div className="eyebrow">{isTeacher ? 'TEACHER WORKSPACE' : 'YOUR LEARNING JOURNEY'}</div><h1>{profile.display_name || 'こんにちは'} さん、{isTeacher ? '今日の授業を準備しよう' : '今日も一歩ずつ！'} <span className="wave">✦</span></h1><p className="muted">{isTeacher ? '授業・課題・生徒の学びをここで管理できます。' : '自分のペースで、一歩ずつ進めよう。'}</p></div><button className="primary-button" onClick={() => isTeacher ? setShowAssignmentForm(true) : setShowLogForm(true)}><Plus size={17}/>{isTeacher ? '課題を作成' : '学習を記録'}</button></section>
      {notice && <div className="notice" role="status"><span>{notice}</span><button className="icon-button" onClick={() => setNotice('')} aria-label="閉じる"><X size={15}/></button></div>}
      {section === 'home' && <><section className="hero-card"><div className="hero-copy"><span className="hero-kicker"><GraduationCap size={14}/> QUL STUDY PLUS+</span><h2>{isTeacher ? <>生徒の学びを、<br/>一緒に育てよう。</> : <>昨日の自分より、<br/>ちょっと先へ。</>}</h2><p>{isTeacher ? '授業と課題をまとめて管理。' : '小さな積み重ねが、大きな成長につながる。'}</p><button className="hero-link" onClick={() => setSection(isTeacher ? 'students' : 'study')}>{isTeacher ? '生徒を管理する' : '学習記録を見る'} <ArrowRight size={16}/></button></div><div className="hero-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="book-illustration"><BookOpen size={62} strokeWidth={1.2}/></div><div className="spark spark-one">✦</div><div className="spark spark-two">✧</div><div className="art-caption">KEEP<br/>GROWING</div></div></section>
      <section className="stats-grid"><article className="stat-card"><div className="stat-head"><span>{isTeacher ? '担当授業' : '学習記録合計'}</span><span className="stat-icon blue-icon"><Clock3 size={18}/></span></div><div className="stat-value">{isTeacher ? myLessons.length : Math.floor(weeklyMinutes / 60)} <small>{isTeacher ? '件' : '時間'}{!isTeacher && <>{weeklyMinutes % 60}分</>}</small></div><div className="stat-note">{isTeacher ? '登録されている授業' : '保存済みの学習記録'}</div></article><article className="stat-card"><div className="stat-head"><span>{isTeacher ? '公開中の課題' : '提出した課題'}</span><span className="stat-icon purple-icon"><CheckCircle2 size={18}/></span></div><div className="stat-value">{isTeacher ? assignments.filter(a => a.teacher_id === profile.id && a.status === 'published').length : mySubmissions.filter(s => s.submitted_at).length}<small> 件</small></div><div className="stat-note">{isTeacher ? '生徒に公開済み' : '提出履歴から集計'}</div></article><article className="stat-card"><div className="stat-head"><span>{isTeacher ? '登録した教材' : '予約済み授業'}</span><span className="stat-icon orange-icon"><BookOpen size={18}/></span></div><div className="stat-value">{isTeacher ? materials.filter(m => m.teacher_id === profile.id).length : myEnrollments.length}<small> 件</small></div><div className="stat-note">{isTeacher ? '教材リンク' : '授業の予約状況'}</div></article></section>
      <section className="dashboard-grid"><article className="panel"><div className="panel-heading"><div><h3>{isTeacher ? '最近の課題' : 'やることリスト'}</h3><p>{isTeacher ? '公開した課題' : '提出期限と進捗を確認しよう'}</p></div><button className="text-link" onClick={() => setSection('tasks')}>すべて見る <ArrowRight size={14}/></button></div>{availableAssignments.slice(0,4).length ? <div className="task-list">{availableAssignments.slice(0,4).map(a => <div className="task-row" key={a.id}><div className="subject-icon blue"><FileText size={18}/></div><div className="task-main"><b>{a.title}</b><span>{a.due_at ? `期限：${new Date(a.due_at).toLocaleString('ja-JP')}` : '期限なし'}</span></div><span className={`status ${isTeacher ? 'in-progress' : mySubmissions.some(s => s.assignment_id === a.id && s.submitted_at) ? 'done' : ''}`}>{isTeacher ? (a.status === 'published' ? '公開中' : '下書き') : mySubmissions.some(s => s.assignment_id === a.id && s.submitted_at) ? '提出済み' : '未提出'}</span></div>)}</div> : <div className="empty-state"><FileText size={24}/><b>課題はまだありません</b><p>{isTeacher ? '「課題を作成」から登録できます。' : '先生が課題を公開するとここに表示されます。'}</p></div>}</article><article className="panel"><div className="panel-heading"><div><h3>授業・予約</h3><p>授業予定をチェック</p></div><CalendarDays size={20}/></div>{myLessons.slice(0,3).length ? <div className="task-list">{myLessons.slice(0,3).map(l => <div className="task-row" key={l.id}><div className="subject-icon purple"><Video size={18}/></div><div className="task-main"><b>{l.title}</b><span>{new Date(l.starts_at).toLocaleString('ja-JP')}</span></div><span className="status">{l.status === 'live' ? '授業中' : l.status === 'completed' ? '終了' : '予定'}</span></div>)}</div> : <div className="empty-state"><GraduationCap size={24}/><b>授業はまだありません</b><p>{isTeacher ? '「授業・予約」から登録できます。' : '授業を探して予約してみよう。'}</p><button className="secondary-button" onClick={() => setSection('lessons')}>授業を見る <ArrowRight size={15}/></button></div>}</article></section></>}
      {section === 'tasks' && <section className="panel full-panel"><div className="panel-heading"><div><h3>{isTeacher ? '課題管理' : '課題一覧'}</h3><p>{isTeacher ? '課題を作成して生徒に公開します。' : '課題を確認して、回答を提出しよう。'}</p></div>{isTeacher && <button className="primary-button" onClick={() => setShowAssignmentForm(!showAssignmentForm)}><Plus size={16}/> 課題を作成</button>}</div>{showAssignmentForm && isTeacher && <form className="inline-form" onSubmit={createAssignment}><label>課題名<input value={assignmentTitle} onChange={e=>setAssignmentTitle(e.target.value)} required maxLength={120} placeholder="例：数学 正負の数"/></label><label>説明<textarea value={assignmentInstructions} onChange={e=>setAssignmentInstructions(e.target.value)} rows={3} placeholder="課題の内容や提出方法"/></label><label>提出期限<input type="datetime-local" value={assignmentDue} onChange={e=>setAssignmentDue(e.target.value)}/></label><button className="primary-button" disabled={busy}>公開する</button></form>}{availableAssignments.length ? <div className="record-list">{availableAssignments.map(a => <article className="record-card" key={a.id}><div className="record-top"><div className="record-icon"><FileText size={20}/></div><div className="record-title"><h4>{a.title}</h4><p>{a.instructions || '説明はありません。'}</p><small>{a.due_at ? `提出期限：${new Date(a.due_at).toLocaleString('ja-JP')}` : '提出期限なし'} · {a.status === 'published' ? '公開中' : '下書き'}</small></div></div>{!isTeacher && a.status === 'published' && <div className="submission-area"><label>提出内容<textarea value={submissionDrafts[a.id] || ''} onChange={e=>setSubmissionDrafts(prev=>({...prev,[a.id]:e.target.value}))} rows={3} placeholder="回答や先生へのメッセージを入力"/></label><button className="primary-button" disabled={busy} onClick={() => void saveSubmission(a.id)}>{mySubmissions.some(s=>s.assignment_id===a.id && s.submitted_at) ? '提出内容を更新' : '提出する'}</button>{mySubmissions.find(s=>s.assignment_id===a.id)?.feedback && <p className="feedback">先生からのコメント：{mySubmissions.find(s=>s.assignment_id===a.id)?.feedback}</p>}</div>}{isTeacher && <p className="record-meta">提出数：{submissions.filter(s=>s.assignment_id===a.id && s.submitted_at).length}件</p>}</article>)}</div> : <div className="empty-state"><FileText size={28}/><b>課題はまだありません</b><p>{isTeacher ? '最初の課題を作成してください。' : '先生が課題を公開するとここに表示されます。'}</p></div>}</section>}
      {section === 'lessons' && <section className="panel full-panel"><div className="panel-heading"><div><h3>授業・予約</h3><p>{isTeacher ? '授業予定を作成し、開始・終了を管理します。' : '参加したい授業を予約できます。'}</p></div>{isTeacher && <button className="primary-button" onClick={() => setShowLessonForm(!showLessonForm)}><Plus size={16}/> 授業を登録</button>}</div>{showLessonForm && isTeacher && <form className="inline-form" onSubmit={createLesson}><label>授業名<input value={lessonTitle} onChange={e=>setLessonTitle(e.target.value)} required maxLength={120} placeholder="例：中1数学 質問教室"/></label><label>説明<textarea value={lessonDescription} onChange={e=>setLessonDescription(e.target.value)} rows={2} placeholder="授業内容・準備物"/></label><div className="form-two"><label>開始日時<input type="datetime-local" value={lessonStarts} onChange={e=>setLessonStarts(e.target.value)} required/></label><label>終了日時<input type="datetime-local" value={lessonEnds} onChange={e=>setLessonEnds(e.target.value)} required min={lessonStarts || undefined}/></label></div><button className="primary-button" disabled={busy || !lessonStarts || !lessonEnds || lessonEnds <= lessonStarts}>授業を登録</button></form>}{availableLessons.length ? <div className="record-list">{availableLessons.map(l => <article className="record-card" key={l.id}><div className="record-top"><div className="record-icon"><Video size={20}/></div><div className="record-title"><h4>{l.title}</h4><p>{l.description || '授業の説明はありません。'}</p><small>{new Date(l.starts_at).toLocaleString('ja-JP')} 〜 {new Date(l.ends_at).toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'})}</small></div><span className={`status ${l.status==='live'?'done':''}`}>{l.status==='live'?'授業中':l.status==='completed'?'終了':l.status==='cancelled'?'中止':'予定'}</span></div><div className="record-actions">{isTeacher ? <>{l.status === 'scheduled' && <button className="primary-button" onClick={() => void updateLessonStatus(l,'live')}><Video size={15}/> 授業開始</button>}{l.status === 'live' && <button className="secondary-button" onClick={() => void updateLessonStatus(l,'completed')}>授業を終了</button>}<span className="record-meta">予約：{enrollments.filter(e=>e.lesson_id===l.id).length}人</span></> : l.status==='scheduled' && !myEnrollments.some(e=>e.lesson_id===l.id) ? <button className="primary-button" disabled={busy} onClick={() => void enroll(l.id)}>この授業を予約</button> : myEnrollments.some(e=>e.lesson_id===l.id) ? <span className="status done">予約済み</span> : null}{l.status==='live' && !isTeacher && <span className="notice-inline">先生が授業中です。入室機能は次の更新で追加します。</span>}</div></article>)}</div> : <div className="empty-state"><CalendarDays size={28}/><b>授業はまだありません</b><p>{isTeacher ? '授業を登録すると、生徒が予約できるようになります。' : '先生が授業を登録すると、ここから予約できます。'}</p></div>}</section>}
      {section === 'study' && <section className="panel full-panel"><div className="panel-heading"><div><h3>学習記録</h3><p>学習した時間を記録して振り返ろう。</p></div><button className="primary-button" onClick={() => setShowLogForm(!showLogForm)}><Plus size={16}/> 記録を追加</button></div>{showLogForm && <form className="inline-form" onSubmit={createStudyLog}><div className="form-two"><label>教科<select value={logSubject} onChange={e=>setLogSubject(e.target.value)}>{['数学','英語','国語','理科','社会','その他'].map(x=><option key={x}>{x}</option>)}</select></label><label>学習時間（分）<input type="number" min="1" max="1440" value={logMinutes} onChange={e=>setLogMinutes(e.target.value)} required/></label></div><label>メモ（任意）<textarea rows={2} value={logNote} onChange={e=>setLogNote(e.target.value)} placeholder="学習した内容や気づき"/></label><button className="primary-button" disabled={busy}>記録を保存</button></form>}<div className="study-summary"><span>保存済み合計</span><strong>{Math.floor(weeklyMinutes/60)}時間 {weeklyMinutes%60}分</strong></div>{logs.length ? <div className="record-list">{logs.map(log=><article className="log-row" key={log.id}><div className="record-icon"><Clock3 size={20}/></div><div className="record-title"><h4>{log.subject} · {log.minutes}分</h4><p>{log.note || 'メモなし'}</p><small>{new Date(`${log.studied_on}T00:00:00`).toLocaleDateString('ja-JP')}</small></div></article>)}</div> : <div className="empty-state"><Clock3 size={28}/><b>学習記録はまだありません</b><p>記録を追加すると、ここに保存されます。</p></div>}</section>}
      {section === 'materials' && <section className="panel full-panel"><div className="panel-heading"><div><h3>教材・資料</h3><p>{isTeacher ? '共有したい教材のURLを登録できます。' : '先生が共有した教材を確認できます。'}</p></div>{isTeacher && <button className="primary-button" onClick={() => setShowMaterialForm(!showMaterialForm)}><Plus size={16}/> 教材を追加</button>}</div>{showMaterialForm && isTeacher && <form className="inline-form" onSubmit={createMaterial}><label>教材名<input value={materialTitle} onChange={e=>setMaterialTitle(e.target.value)} required maxLength={120} placeholder="例：数学の復習プリント"/></label><label>説明<textarea rows={2} value={materialDescription} onChange={e=>setMaterialDescription(e.target.value)} placeholder="教材の説明"/></label><label>URL<input type="url" value={materialUrl} onChange={e=>setMaterialUrl(e.target.value)} required placeholder="https://..."/></label><button className="primary-button" disabled={busy}>教材を登録</button></form>}{materials.filter(m=>isTeacher ? m.teacher_id===profile.id : true).length ? <div className="record-list">{materials.filter(m=>isTeacher ? m.teacher_id===profile.id : true).map(m=><article className="record-card" key={m.id}><div className="record-top"><div className="record-icon"><BookOpen size={20}/></div><div className="record-title"><h4>{m.title}</h4><p>{m.description || '説明なし'}</p><a href={m.url} target="_blank" rel="noreferrer" className="text-link">教材を開く <ArrowRight size={14}/></a></div></div></article>)}</div> : <div className="empty-state"><BookOpen size={28}/><b>教材はまだありません</b><p>{isTeacher ? '教材のURLを登録してください。' : '先生が教材を登録するとここに表示されます。'}</p></div>}</section>}
      {section === 'students' && isTeacher && <section className="panel full-panel"><div className="panel-heading"><div><h3>生徒管理</h3><p>先生が発行したアカウントを管理します。</p></div><a className="primary-button" href="/teacher/students/">生徒を登録 <ArrowRight size={15}/></a></div><p className="muted">生徒アカウントの発行画面では、名前とメールアドレスを入力して初期パスワードを作成できます。</p></section>}
      <footer>QUL Study PLUS+ <span>学びを、もっとつなぐ。</span><span className="copyright">Copyright © 2026 QUL Group. All Rights Reserved.</span></footer></div></section>
  </main>;
}
